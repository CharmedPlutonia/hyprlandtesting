#!/usr/bin/env bash
# Shared installer helpers. Not copied to ~/.local.

log() { printf '\n\033[1;32m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m!!\033[0m %s\n' "$*" >&2; }
die() { printf '\033[1;31mxx\033[0m %s\n' "$*" >&2; exit 1; }

require_arch() {
  [[ -f /etc/arch-release ]] || die "This installer only supports Arch Linux."
}

require_user() {
  [[ ${EUID:-0} -ne 0 ]] || die "Run this as your normal user. It will call sudo when it needs root."
  command -v sudo >/dev/null 2>&1 || die "sudo is not installed."
  sudo -v || die "sudo authentication failed."
}
