#!/usr/bin/env bash
# Official package list for the shell. Missing names are skipped and reported.
set -euo pipefail

official_packages() {
  cat <<'EOF'
base-devel
git
curl
ca-certificates
pciutils
usbutils
jq
gum
python
imagemagick
file
pacman-contrib
xdg-utils
xdg-user-dirs
xdg-desktop-portal
xdg-desktop-portal-hyprland
xdg-desktop-portal-gtk
hyprland
uwsm
hyprlock
hypridle
hyprpicker
hyprsunset
waybar
mako
swaybg
swayosd
polkit
polkit-gnome
qt5-wayland
qt6-wayland
qt6ct
kvantum
alacritty
xdg-terminal-exec
nautilus
gnome-calculator
grim
slurp
satty
wl-clipboard
cliphist
brightnessctl
pamixer
playerctl
power-profiles-daemon
upower
ttf-jetbrains-mono-nerd
noto-fonts
noto-fonts-cjk
noto-fonts-emoji
greetd
greetd-tuigreet
pipewire
pipewire-pulse
pipewire-alsa
wireplumber
networkmanager
bluez
bluez-utils
btop
tmux
neovim
imv
mpv
ffmpeg
pavucontrol
libnotify
gpu-screen-recorder
v4l-utils
mesa
linux-firmware
EOF
}

# Tried from the AUR only when pacman does not already ship them.
# The browser is chosen separately (ungoogled, drm, or distro chromium).
aur_candidates() {
  cat <<'EOF'
walker
elephant
wiremix
impala
bluetui
EOF
}

# Exact local package name. Do not use `pacman -Q chromium`: that also matches
# a package that *provides* chromium, and `pacman -R chromium` then errors
# with "target not found" even though ungoogled-chromium-widevine-bin is installed.
pkg_installed() {
  local name="$1"
  [[ -n $name ]] || return 1
  command -v pacman >/dev/null 2>&1 || return 1
  if [[ -z ${DEO_INSTALLED_PKGS+x} ]]; then
    DEO_INSTALLED_PKGS="$(pacman -Qq 2>/dev/null || true)"
  fi
  [[ -n $DEO_INSTALLED_PKGS ]] || return 1
  printf '%s\n' "$DEO_INSTALLED_PKGS" | grep -qxF -- "$name"
}

installed_browsers() {
  local name
  while IFS= read -r name; do
    [[ -n $name ]] || continue
    if pkg_installed "$name"; then
      printf '%s\n' "$name"
    fi
  done <<'EOF'
ungoogled-chromium-widevine-bin
ungoogled-chromium
ungoogled-chromium-bin
chromium
chromium-bin
google-chrome
google-chrome-beta
google-chrome-dev
EOF
}
