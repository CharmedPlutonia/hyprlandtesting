chrome.commands.onCommand.addListener((command) => {
  if (command !== "copy-url") return;
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs && tabs[0];
    if (!tab) return;
    chrome.scripting
      .executeScript({
        target: { tabId: tab.id },
        func: () => navigator.clipboard.writeText(window.location.href),
      })
      .then(() => {
        chrome.notifications.create({
          type: "basic",
          iconUrl:
            "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8/5+hHgAHggJ/PchI7wAAAABJRU5ErkJggg==",
          title: "URL copied",
          message: "",
        });
      })
      .catch(() => {});
  });
});
