#!/usr/bin/env bash
icon="$(curl -fsS --max-time 4 "https://wttr.in?format=%c" 2>/dev/null | tr -d '\n')"
if [[ -n $icon ]]; then
  icon="${icon//\\/\\\\}"
  icon="${icon//\"/\\\"}"
  printf '{"text":"%s"}\n' "$icon"
else
  printf '{"text":"","class":"unavailable"}\n'
fi
