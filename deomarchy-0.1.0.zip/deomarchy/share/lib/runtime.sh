#!/usr/bin/env bash
# Shared helpers for deo-* commands. Installed to ~/.local/share/deomarchy/lib/runtime.sh

deo_notify() {
  command -v notify-send >/dev/null 2>&1 && notify-send -u low "$@"
}

deo_launch() {
  if command -v uwsm-app >/dev/null 2>&1; then
    exec setsid uwsm-app -- "$@"
  else
    exec setsid "$@"
  fi
}

deo_launch_bg() {
  if command -v uwsm-app >/dev/null 2>&1; then
    setsid uwsm-app -- "$@" >/dev/null 2>&1 &
  else
    setsid "$@" >/dev/null 2>&1 &
  fi
}

deo_browser_bin() {
  local desktop="" bin="" f
  desktop="$(xdg-settings get default-web-browser 2>/dev/null || true)"
  case "$desktop" in
    google-chrome* | brave* | microsoft-edge* | opera* | vivaldi* | helium* | chromium* | ungoogled*) ;;
    *) desktop="" ;;
  esac
  if [[ -z $desktop ]]; then
    for desktop in ungoogled-chromium.desktop chromium.desktop; do
      for f in "$HOME/.local/share/applications/$desktop" "/usr/share/applications/$desktop"; do
        [[ -f $f ]] && break 2
      done
      desktop=""
    done
  fi
  if [[ -n $desktop ]]; then
    for f in "$HOME/.local/share/applications/$desktop" "/usr/share/applications/$desktop"; do
      [[ -f $f ]] || continue
      bin="$(sed -n 's/^Exec=\([^ ]*\).*/\1/p' "$f" | head -1)"
      bin="${bin%\"}"
      bin="${bin#\"}"
      [[ -n $bin ]] && break
    done
  fi
  if [[ -z $bin || ! -x $bin ]]; then
    bin="$(command -v ungoogled-chromium || command -v chromium || true)"
  fi
  printf '%s\n' "$bin"
}

deo_focused_monitor() {
  hyprctl monitors -j | jq -r '.[] | select(.focused == true) | .name' | head -1
}
