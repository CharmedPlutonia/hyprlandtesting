#!/usr/bin/env bash
# deomarchy — Hyprland shell from Omarchy 3.8.4, installed onto plain Arch.
# Does not install Omarchy, its repo, its kernel, or its loosened sudo/PAM.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERSION="$(tr -d '[:space:]' <"$ROOT/VERSION" 2>/dev/null || true)"
VERSION="${VERSION:-0.1.0}"
# shellcheck source=lib/common.sh
source "$ROOT/lib/common.sh"
# shellcheck source=lib/packages.sh
source "$ROOT/lib/packages.sh"

DRY=0
RECONFIGURE=0
SKIP_AUR=0
HEY_MAILTO=0
FETCH=ask
WEBAPPS=ask
UPDATE=ask
BROWSER=ask
FETCH_SUMMARY="not installed"
BROWSER_SUMMARY="not installed"

usage() {
  cat <<EOF
Usage: ./install.sh [options]

  deomarchy $VERSION

  --dry-run        Print the hardware report and package list. Change nothing.
  --reconfigure    Overwrite ~/.config files shipped by this repo (backs them up).
  --skip-aur       Skip yay and every AUR package, including an AUR browser.
  --hey-mailto     Also install HEY and make it the default mailto: handler.
  --fetch TOOL     fastfetch, neofetch, both, or none. Default: ask, else fastfetch.
  --webapps WHICH  all, none, ask, or a list such as HEY,Grok. Default: ask, else none.
  --update         Run pacman -Syu before installing anything.
  --skip-update    Do not check for or apply system updates.
  --browser WHICH  ungoogled, drm, or chromium. Default: ask before anything is installed.
                   ungoogled  AUR ungoogled-chromium-bin (no DRM)
                   drm        AUR ungoogled-chromium-widevine-bin
                   chromium   distro chromium from the official repos
  -h, --help       Show this help.

Run it from a normal user on a base Arch install (archinstall's minimal
profile is the intended starting point). Reboot when it finishes.
The default theme is catppuccin-mocha.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --dry-run) DRY=1 ;;
    --reconfigure) RECONFIGURE=1 ;;
    --skip-aur) SKIP_AUR=1 ;;
    --hey-mailto) HEY_MAILTO=1 ;;
    --fetch)
      [[ $# -ge 2 ]] || die "--fetch needs fastfetch, neofetch, both, or none"
      FETCH="$2"
      shift
      ;;
    --fetch=*) FETCH="${1#*=}" ;;
    --webapps)
      [[ $# -ge 2 ]] || die "--webapps needs all, none, ask, or a comma-separated list"
      WEBAPPS="$2"
      shift
      ;;
    --webapps=*) WEBAPPS="${1#*=}" ;;
    --update) UPDATE=yes ;;
    --skip-update) UPDATE=no ;;
    --browser)
      [[ $# -ge 2 ]] || die "--browser needs ungoogled, drm, or chromium"
      BROWSER="$2"
      case "$BROWSER" in
        widevine) BROWSER=drm ;;
        distro) BROWSER=chromium ;;
        plain) BROWSER=ungoogled ;;
      esac
      shift
      ;;
    --browser=*) BROWSER="${1#*=}" ;;
    -h | --help) usage; exit 0 ;;
    *) die "Unknown option: $1" ;;
  esac
  shift
done

case "$FETCH" in
  ask | fastfetch | neofetch | both | none) ;;
  *) die "Unknown --fetch value: $FETCH (use fastfetch, neofetch, both, none, or ask)" ;;
esac
case "$WEBAPPS" in
  ask | all | none) ;;
  "") die "--webapps needs a value" ;;
  *) ;;
esac
case "$UPDATE" in
  ask | yes | no) ;;
  *) die "Unknown update mode: $UPDATE" ;;
esac
case "$BROWSER" in
  ask | ungoogled | drm | chromium) ;;
  *) die "--browser must be ungoogled, drm, or chromium (got: $BROWSER)" ;;
esac

log "deomarchy $VERSION"
require_arch

if [[ $DRY -eq 1 ]]; then
  require_user
  log "Hardware"
  bash "$ROOT/lib/hardware.sh" --report | tee "$HOME/deomarchy-hardware.txt"
  log "Official packages"
  official_packages
  log "AUR candidates (installed only when pacman does not have them)"
  aur_candidates
  log "Chosen when you actually install"
  cat <<EOF
fetch:     fastfetch (extra) or neofetch (AUR only)
           --fetch fastfetch|neofetch|both|none
web apps:  none unless you pick them
           --webapps all|none|HEY,Grok
updates:   asked up front. Default answer is no.
           --update always upgrades. --skip-update never checks.
browser:   asked up front, before anything is installed
           --browser ungoogled|drm|chromium
theme:     catppuccin-mocha
           https://github.com/KidDogDad/omarchy-catppuccin-mocha-theme
EOF
  log "Dry run only. Nothing was installed."
  exit 0
fi

ask_yes_no() {
  local prompt="$1" ans
  if [[ -t 0 ]] && command -v gum >/dev/null 2>&1; then
    ans="$(gum choose --header "$prompt" No Yes)" || return 1
    [[ $ans == Yes ]]
    return
  fi
  if [[ -t 0 ]]; then
    read -r -p "$prompt [y/N] " ans || true
    [[ $ans == [yY] || $ans == [yY][eE][sS] ]]
    return
  fi
  return 1
}

apply_system_updates() {
  if [[ $UPDATE == yes ]]; then
    log "Applying system updates (pacman -Syu)"
    sudo pacman -Syu --noconfirm
  else
    log "Skipping system update."
  fi
}

choose_one() {
  local header="$1" def="$2" i ans pick
  shift 2
  local -a opts=("$@")
  if [[ ! -t 0 ]]; then
    printf '%s\n' "${opts[$((def - 1))]}"
    return 0
  fi
  if command -v gum >/dev/null 2>&1; then
    local -a ordered=("${opts[$((def - 1))]}")
    local o
    for o in "${opts[@]}"; do
      [[ $o == "${ordered[0]}" ]] || ordered+=("$o")
    done
    if pick="$(gum choose --header "$header. Enter keeps the first line." "${ordered[@]}")"; then
      printf '%s\n' "$pick"
      return 0
    fi
  fi
  printf '%s\n' "$header" >&2
  i=1
  for pick in "${opts[@]}"; do
    if [[ $i -eq $def ]]; then
      printf '  %d) %s  [default]\n' "$i" "$pick" >&2
    else
      printf '  %d) %s\n' "$i" "$pick" >&2
    fi
    i=$((i + 1))
  done
  read -r -p "Choice [$def]: " ans || true
  [[ -n $ans ]] || ans="$def"
  if [[ $ans =~ ^[0-9]+$ ]] && ((ans >= 1 && ans <= ${#opts[@]})); then
    printf '%s\n' "${opts[$((ans - 1))]}"
    return 0
  fi
  printf '%s\n' "${opts[$((def - 1))]}"
}

pending_update_count() {
  local list_file cu_rc count
  list_file="$(mktemp)"
  if command -v checkupdates >/dev/null 2>&1; then
    set +e
    checkupdates >"$list_file" 2>/dev/null
    cu_rc=$?
    set -e
    if [[ $cu_rc -eq 1 ]]; then
      warn "checkupdates failed. Using pacman -Qu on the current database."
      pacman -Qu >"$list_file" 2>/dev/null || : >"$list_file"
    fi
  else
    pacman -Qu >"$list_file" 2>/dev/null || : >"$list_file"
  fi
  count="$(grep -c . "$list_file" || true)"
  if [[ ${count:-0} -gt 0 ]]; then
    log "$count package update(s) available."
    head -n 20 "$list_file" >&2 || true
    if [[ $count -gt 20 ]]; then
      echo "... and $((count - 20)) more" >&2
    fi
  fi
  rm -f "$list_file"
  printf '%s\n' "${count:-0}"
}

ask_all_questions() {
  local pick count names_file name text hey=0
  local -a names=()
  local opt_ungoogled opt_drm opt_chromium def_browser

  printf '\n%s\n' "deomarchy $VERSION — choices are made before anything is installed." >&2

  if [[ $UPDATE == ask ]]; then
    if [[ -t 0 ]]; then
      count="$(pending_update_count)"
      if [[ ${count:-0} -eq 0 ]]; then
        UPDATE=no
        log "No package updates."
      elif ask_yes_no "Apply these system updates before installing?"; then
        UPDATE=yes
      else
        UPDATE=no
      fi
    else
      UPDATE=no
      warn "No prompt. Skipping system updates. Pass --update to apply them."
    fi
  fi

  if [[ $BROWSER == ask ]]; then
    opt_ungoogled="Ungoogled Chromium, no DRM"
    opt_drm="Ungoogled Chromium with DRM"
    opt_chromium="Distro Chromium"
    pkg_installed ungoogled-chromium-bin && opt_ungoogled="$opt_ungoogled [installed]"
    pkg_installed ungoogled-chromium && opt_ungoogled="$opt_ungoogled [installed]"
    pkg_installed ungoogled-chromium-widevine-bin && opt_drm="$opt_drm [installed]"
    pkg_installed chromium && opt_chromium="$opt_chromium [installed]"
    def_browser=2
    if pkg_installed ungoogled-chromium-widevine-bin; then
      def_browser=2
    elif pkg_installed ungoogled-chromium-bin || pkg_installed ungoogled-chromium; then
      def_browser=1
    elif pkg_installed chromium; then
      def_browser=3
    fi
    if [[ -t 0 ]]; then
      pick="$(choose_one "Browser" "$def_browser" "$opt_ungoogled" "$opt_drm" "$opt_chromium")"
    else
      pick="$opt_drm"
      warn "No prompt. Browser defaults to ungoogled Chromium with DRM if nothing else is set."
      if pkg_installed chromium && ! pkg_installed ungoogled-chromium-widevine-bin && ! pkg_installed ungoogled-chromium-bin; then
        pick="$opt_chromium"
      elif pkg_installed ungoogled-chromium-bin || pkg_installed ungoogled-chromium; then
        pick="$opt_ungoogled"
      fi
    fi
    case "$pick" in
      Distro*) BROWSER=chromium ;;
      *"no DRM"*) BROWSER=ungoogled ;;
      *) BROWSER=drm ;;
    esac
  fi

  if [[ $FETCH == ask ]]; then
    if [[ -t 0 ]]; then
      pick="$(choose_one "Terminal system info. fastfetch is in the repos. neofetch is AUR." 1 fastfetch neofetch both none)"
      FETCH="$pick"
    else
      FETCH=fastfetch
      warn "No prompt. Installing fastfetch. Pass --fetch neofetch, both, or none to change that."
    fi
  fi

  if [[ $WEBAPPS == ask ]]; then
    names_file="$(mktemp)"
    awk -F '\t' 'NF && $1 !~ /^#/ { print $1 }' "$ROOT/share/webapps/defaults.tsv" >"$names_file"
    while IFS= read -r name; do
      [[ -n $name ]] && names+=("$name")
    done <"$names_file"
    rm -f "$names_file"
    if [[ -t 0 ]] && command -v gum >/dev/null 2>&1; then
      echo "Web apps are optional. Space toggles, enter confirms. Select none to skip." >&2
      if text="$(gum choose --no-limit --header "Optional web apps" "${names[@]}")"; then
        if [[ -z $text ]]; then
          WEBAPPS=none
        else
          WEBAPPS="$(printf '%s\n' "$text" | paste -sd, -)"
        fi
      else
        WEBAPPS=none
      fi
    elif [[ -t 0 ]]; then
      echo "Optional web apps. Enter numbers separated by spaces, 'all', or press enter for none." >&2
      local i=1
      for name in "${names[@]}"; do
        printf '  %2d) %s\n' "$i" "$name" >&2
        i=$((i + 1))
      done
      read -r -p "Web apps [none]: " text || true
      if [[ -z $text || $text == none ]]; then
        WEBAPPS=none
      elif [[ $text == all ]]; then
        WEBAPPS=all
      else
        WEBAPPS=""
        for i in $text; do
          if [[ $i =~ ^[0-9]+$ ]] && ((i >= 1 && i <= ${#names[@]})); then
            WEBAPPS="${WEBAPPS:+$WEBAPPS,}${names[$((i - 1))]}"
          fi
        done
        [[ -n $WEBAPPS ]] || WEBAPPS=none
      fi
    else
      WEBAPPS=none
      warn "No web apps installed. Pass --webapps all or --webapps HEY,Grok."
    fi
  fi

  if [[ $HEY_MAILTO -eq 0 && $WEBAPPS != none && $WEBAPPS == *HEY* && -t 0 ]]; then
    if ask_yes_no "Make HEY the default mailto: handler?"; then
      HEY_MAILTO=1
    fi
  fi

  case "$BROWSER" in
    ungoogled) BROWSER_SUMMARY="ungoogled-chromium-bin (no DRM)" ;;
    drm) BROWSER_SUMMARY="ungoogled-chromium-widevine-bin (DRM)" ;;
    chromium) BROWSER_SUMMARY="chromium (distro)" ;;
  esac

  cat >&2 <<EOF

Choices
  version:  $VERSION
  updates:  $UPDATE
  browser:  $BROWSER_SUMMARY
  fetch:    $FETCH
  web apps: $WEBAPPS
  mailto:   $([[ $HEY_MAILTO -eq 1 ]] && echo HEY || echo unchanged)

EOF
  if [[ -t 0 ]]; then
    if ! ask_default_yes "Start the install with these choices?"; then
      log "Cancelled. Nothing was changed."
      exit 0
    fi
  fi
}

ask_default_yes() {
  local prompt="$1" ans
  if [[ -t 0 ]] && command -v gum >/dev/null 2>&1; then
    ans="$(gum choose --header "$prompt" Yes No)" || return 1
    [[ $ans == Yes ]]
    return
  fi
  if [[ -t 0 ]]; then
    read -r -p "$prompt [Y/n] " ans || true
    [[ -z $ans || $ans == [yY] || $ans == [yY][eE][sS] ]]
    return
  fi
  return 0
}

ask_all_questions
require_user

log "Keeps packages that are already installed. A browser is removed only if you picked a different conflicting build."
log "Hardware"
bash "$ROOT/lib/hardware.sh" --report | tee "$HOME/deomarchy-hardware.txt"

log "System update"
apply_system_updates

log "Official packages"
pkg_file="$(mktemp)"
official_packages >"$pkg_file"
to_install=()
not_in_repo=()
already_n=0
while IFS= read -r pkg; do
  [[ -n $pkg ]] || continue
  if pkg_installed "$pkg"; then
    already_n=$((already_n + 1))
    continue
  fi
  if pacman -Si "$pkg" >/dev/null 2>&1; then
    to_install+=("$pkg")
  else
    not_in_repo+=("$pkg")
  fi
done <"$pkg_file"
rm -f "$pkg_file"
log "Official packages already installed: $already_n"
if [[ ${#to_install[@]} -eq 0 ]]; then
  log "No new official packages."
else
  log "Installing ${#to_install[@]} official package(s): ${to_install[*]}"
  sudo pacman -S --needed --noconfirm "${to_install[@]}"
  unset DEO_INSTALLED_PKGS
fi
if [[ ${#not_in_repo[@]} -gt 0 ]]; then
  warn "Not in the official repos (skipped): ${not_in_repo[*]}"
fi

log "Drivers for this machine"
bash "$ROOT/lib/hardware.sh" --install

install_yay() {
  if command -v yay >/dev/null 2>&1; then
    return 0
  fi
  log "Installing yay-bin"
  local tmp
  tmp="$(mktemp -d)"
  if ! git clone --depth 1 https://aur.archlinux.org/yay-bin.git "$tmp/yay-bin"; then
    rm -rf "$tmp"
    warn "Could not clone yay-bin."
    return 1
  fi
  if ! (cd "$tmp/yay-bin" && makepkg -si --noconfirm); then
    rm -rf "$tmp"
    warn "Could not build yay-bin."
    return 1
  fi
  rm -rf "$tmp"
}

install_aur() {
  local pkg
  unset DEO_INSTALLED_PKGS
  if ! install_yay; then
    warn "yay is not available. Skipping AUR packages."
    return 0
  fi
  for pkg in $(aur_candidates); do
    if pkg_installed "$pkg"; then
      log "Already installed: $pkg"
      continue
    fi
    if pacman -Si "$pkg" >/dev/null 2>&1; then
      log "Installing $pkg from the official repos"
      sudo pacman -S --needed --noconfirm "$pkg" && continue
    fi
    log "Installing $pkg from the AUR"
    yay -S --needed --noconfirm --answerdiff None --answerclean All --removemake "$pkg" \
      || warn "AUR package failed: $pkg. The rest of the install will still run."
  done
}

remove_exact_pkg() {
  local name="$1" why="$2"
  if pkg_installed "$name"; then
    warn "Removing $name. $why"
    if ! sudo pacman -R --noconfirm "$name"; then
      warn "Could not remove $name."
      return 1
    fi
    unset DEO_INSTALLED_PKGS
  fi
}

install_chosen_browser() {
  local pkg="" name
  local -a conflicts=()
  case "$BROWSER" in
    ungoogled)
      if pkg_installed ungoogled-chromium-bin || pkg_installed ungoogled-chromium; then
        log "Ungoogled Chromium is already installed. Not installing another build."
        if pkg_installed ungoogled-chromium-bin; then
          BROWSER_SUMMARY="ungoogled-chromium-bin (already installed)"
        else
          BROWSER_SUMMARY="ungoogled-chromium (already installed)"
        fi
        return 0
      fi
      pkg="ungoogled-chromium-bin"
      conflicts=(chromium chromium-bin ungoogled-chromium-widevine-bin)
      ;;
    drm)
      pkg="ungoogled-chromium-widevine-bin"
      if pkg_installed "$pkg"; then
        log "Already installed: $pkg"
        BROWSER_SUMMARY="$pkg (already installed)"
        return 0
      fi
      conflicts=(chromium chromium-bin ungoogled-chromium ungoogled-chromium-bin)
      ;;
    chromium)
      pkg="chromium"
      if pkg_installed "$pkg"; then
        log "Already installed: $pkg"
        BROWSER_SUMMARY="$pkg (already installed)"
        return 0
      fi
      conflicts=(ungoogled-chromium ungoogled-chromium-bin ungoogled-chromium-widevine-bin chromium-bin)
      ;;
    *)
      warn "No browser selected."
      return 0
      ;;
  esac
  BROWSER_SUMMARY="$pkg"
  if [[ $SKIP_AUR -eq 1 && $BROWSER != chromium ]]; then
    warn "--skip-aur is set, so $pkg was not installed."
    BROWSER_SUMMARY="$pkg (skipped, AUR disabled)"
    return 0
  fi
  for name in "${conflicts[@]}"; do
    remove_exact_pkg "$name" "It conflicts with $pkg." || {
      BROWSER_SUMMARY="$name (kept, could not switch)"
      return 0
    }
  done
  unset DEO_INSTALLED_PKGS
  if [[ $BROWSER == chromium ]]; then
    log "Installing distro chromium"
    sudo pacman -S --needed --noconfirm chromium \
      || warn "Could not install chromium. The rest of the install will still run."
    return 0
  fi
  if ! install_yay; then
    warn "yay is not available, so $pkg was not installed."
    return 0
  fi
  log "Installing $pkg from the AUR"
  yay -S --needed --noconfirm --answerdiff None --answerclean All --removemake "$pkg" \
    || warn "AUR package failed: $pkg. The rest of the install will still run."
}

if [[ $SKIP_AUR -eq 0 ]]; then
  log "AUR packages (only ones that are not already installed)"
  install_aur
else
  warn "Skipping AUR packages other than a distro browser, if you picked one."
fi

log "Browser ($BROWSER_SUMMARY)"
install_chosen_browser

install_fastfetch() {
  if pkg_installed fastfetch; then
    log "Already installed: fastfetch"
    return 0
  fi
  if pacman -Si fastfetch >/dev/null 2>&1; then
    sudo pacman -S --needed --noconfirm fastfetch
  else
    warn "fastfetch is not in the official repos on this machine."
    return 1
  fi
}

install_neofetch() {
  if pkg_installed neofetch; then
    log "Already installed: neofetch"
    return 0
  fi
  if pacman -Si neofetch >/dev/null 2>&1; then
    sudo pacman -S --needed --noconfirm neofetch
    return 0
  fi
  warn "neofetch is not in the official repos. It is an AUR package."
  if [[ $SKIP_AUR -eq 1 ]]; then
    warn "--skip-aur is set, so neofetch was not installed."
    return 1
  fi
  install_yay
  yay -S --needed --noconfirm --answerdiff None --answerclean All --removemake neofetch \
    || {
      warn "AUR package neofetch failed."
      return 1
    }
}

log "Fetch tool ($FETCH)"
case "$FETCH" in
  none)
    FETCH_SUMMARY="none"
    warn "Not installing fastfetch or neofetch."
    ;;
  fastfetch)
    if install_fastfetch; then
      FETCH_SUMMARY="fastfetch"
    else
      FETCH_SUMMARY="fastfetch failed"
      warn "fastfetch was not installed. The rest of the install will still run."
    fi
    ;;
  neofetch)
    if install_neofetch; then
      FETCH_SUMMARY="neofetch"
    else
      FETCH_SUMMARY="neofetch failed"
      warn "neofetch was not installed. The rest of the install will still run."
    fi
    ;;
  both)
    ff=0
    nf=0
    install_fastfetch && ff=1 || warn "fastfetch was not installed."
    install_neofetch && nf=1 || warn "neofetch was not installed."
    if [[ $ff -eq 1 && $nf -eq 1 ]]; then
      FETCH_SUMMARY="fastfetch and neofetch"
    elif [[ $ff -eq 1 ]]; then
      FETCH_SUMMARY="fastfetch (neofetch failed)"
    elif [[ $nf -eq 1 ]]; then
      FETCH_SUMMARY="neofetch (fastfetch failed)"
    else
      FETCH_SUMMARY="both failed"
    fi
    ;;
esac

log "Installing shell files"
mkdir -p "$HOME/.local/bin" "$HOME/.local/share" "$HOME/.config/hypr/toggles" "$HOME/.config/deomarchy"
rm -rf "$HOME/.local/share/deomarchy"
cp -a "$ROOT/share" "$HOME/.local/share/deomarchy"
find "$HOME/.local/share/deomarchy" -type f -name '*.sh' -exec chmod 755 {} +
while IFS= read -r -d '' src; do
  install -m 755 "$src" "$HOME/.local/bin/$(basename "$src")"
done < <(find "$ROOT/bin" -maxdepth 1 -type f -print0)

# User configs are copied once. --reconfigure replaces them after a backup.
while IFS= read -r -d '' src; do
  rel="${src#"$ROOT/config/"}"
  dest="$HOME/.config/$rel"
  if [[ -e $dest && $RECONFIGURE -eq 0 ]]; then
    continue
  fi
  mkdir -p "$(dirname "$dest")"
  if [[ -e $dest ]]; then
    cp -a "$dest" "$dest.bak.$(date +%Y%m%d%H%M%S)"
  fi
  cp -a "$src" "$dest"
done < <(find "$ROOT/config" -type f -print0)

if [[ ! -f $HOME/.config/hypr/toggles/keep.conf ]]; then
  printf '%s\n' "# placeholder so Hyprland's toggle glob always matches" \
    >"$HOME/.config/hypr/toggles/keep.conf"
fi

# NVIDIA hardware.sh may have written hardware.conf before the template copy.
# Re-run driver env generation if the card is present and the file is still a stub.
if lspci -nn 2>/dev/null | grep -Eiq 'nvidia' && ! grep -q nvidia "$HOME/.config/hypr/hardware.conf"; then
  bash "$ROOT/lib/hardware.sh" --install
fi

mkdir -p "$HOME/.local/share/deomarchy"
cp -f "$HOME/deomarchy-hardware.txt" "$HOME/.local/share/deomarchy/hardware-report.txt" || true

path_line='export PATH="$HOME/.local/bin:$PATH"  # deomarchy'
for rc in "$HOME/.bashrc" "$HOME/.zshrc"; do
  [[ -f $rc ]] || continue
  grep -q 'deomarchy' "$rc" || printf '\n%s\n' "$path_line" >>"$rc"
done
if [[ ! -f $HOME/.bashrc ]]; then
  printf '%s\n' "$path_line" >"$HOME/.bashrc"
fi

mkdir -p "$HOME/.config/uwsm"
if [[ ! -f $HOME/.config/uwsm/env ]] || ! grep -q '/.local/bin' "$HOME/.config/uwsm/env"; then
  printf '%s\n' 'export PATH="$HOME/.local/bin:$PATH"' >>"$HOME/.config/uwsm/env"
fi

export PATH="$HOME/.local/bin:$PATH"
export DEO_SHARE="$HOME/.local/share/deomarchy"

log "Theme (catppuccin-mocha)"
deo-theme-set catppuccin-mocha

log "Browser flags"
ext="$HOME/.local/share/deomarchy/chromium/extensions/copy-url"
  cat >"$HOME/.config/chromium-flags.conf" <<EOF
--ozone-platform=wayland
--ozone-platform-hint=auto
--enable-features=TouchpadOverscrollHistoryNavigation,VaapiVideoDecodeLinuxGL
--disable-features=DisableLoadExtensionCommandLineSwitch
--load-extension=${ext}
EOF
  cp -f "$HOME/.config/chromium-flags.conf" "$HOME/.config/ungoogled-chromium-flags.conf"

  widevine_list="$(mktemp)"
  find /usr/lib /opt -name 'libwidevinecdm.so' 2>/dev/null >"$widevine_list" || true
  while IFS= read -r so; do
    [[ -n $so ]] || continue
    sudo chmod 755 "$so" || true
    log "Widevine module: $so"
  done <"$widevine_list"
  rm -f "$widevine_list"

  desktop=""
  for candidate in ungoogled-chromium.desktop chromium.desktop google-chrome.desktop; do
    if [[ -f /usr/share/applications/$candidate || -f $HOME/.local/share/applications/$candidate ]]; then
      desktop="$candidate"
      break
    fi
  done
  if [[ -n $desktop ]]; then
    mkdir -p "$HOME/.config"
    mime="$HOME/.config/mimeapps.list"
    touch "$mime"
    for handler in text/html x-scheme-handler/http x-scheme-handler/https; do
      if grep -q "^${handler}=" "$mime"; then
        sed -i "s|^${handler}=.*|${handler}=${desktop}|" "$mime"
      else
        if grep -q '^\[Default Applications\]' "$mime"; then
          sed -i "/^\[Default Applications\]/a ${handler}=${desktop}" "$mime"
        else
          printf '\n[Default Applications]\n%s=%s\n' "$handler" "$desktop" >>"$mime"
        fi
      fi
    done
    xdg-settings set default-web-browser "$desktop" || true
    xdg-mime default "$desktop" text/html || true
    xdg-mime default "$desktop" x-scheme-handler/http || true
    xdg-mime default "$desktop" x-scheme-handler/https || true
  else
    warn "Browser desktop file not found. Web apps will not launch until it is installed."
  fi

log "Web apps ($WEBAPPS)"
if [[ $HEY_MAILTO -eq 1 ]]; then
  export DEO_HEY_MAILTO=1
else
  export DEO_HEY_MAILTO=0
fi
webapps_rc=0
case "$WEBAPPS" in
  all | none) deo-webapp-install-defaults "--$WEBAPPS" || webapps_rc=$? ;;
  *) deo-webapp-install-defaults "$WEBAPPS" || webapps_rc=$? ;;
esac
if [[ $webapps_rc -ne 0 ]]; then
  warn "Web app step failed (exit $webapps_rc). The rest of the install will still run."
  warn "Each failure prints the app name, the URL, and why it was refused."
fi

log "Groups (not docker, not a passwordless sudo rule)"
for group in video input audio storage render; do
  if getent group "$group" >/dev/null; then
    sudo usermod -aG "$group" "$USER"
  fi
done

log "greetd + tuigreet"
session=""
if [[ -f /usr/share/wayland-sessions/hyprland-uwsm.desktop ]]; then
  session="uwsm start hyprland-uwsm.desktop"
elif [[ -f /usr/share/wayland-sessions/hyprland.desktop ]]; then
  session="uwsm start -- hyprland.desktop"
else
  session="Hyprland"
fi

sudo mkdir -p /etc/greetd
sudo tee /etc/greetd/config.toml >/dev/null <<EOF
[terminal]
vt = 1

[default_session]
command = "/usr/bin/tuigreet --time --time-format '%A  %H:%M' --remember --remember-user-session --asterisks --window-padding 2 --container-padding 1 --greeting 'login' --theme 'border=cyan;text=white;prompt=cyan;time=blue;action=green;button=magenta;container=black;input=red' --cmd '${session}'"
user = "greeter"
EOF
sudo chmod 644 /etc/greetd/config.toml

for dm in gdm sddm lightdm lxdm; do
  if systemctl is-enabled "$dm.service" >/dev/null 2>&1; then
    warn "Disabling $dm so greetd can own the login screen"
    sudo systemctl disable "$dm.service" || true
  fi
done
sudo systemctl enable greetd.service

log "Services"
# Do not steal the network stack if archinstall already brought one up.
if systemctl is-active --quiet NetworkManager; then
  sudo systemctl enable NetworkManager.service
elif systemctl is-active --quiet systemd-networkd || systemctl is-active --quiet iwd; then
  warn "Leaving the current network manager alone."
else
  sudo systemctl enable --now NetworkManager.service || true
fi

if systemctl --user status >/dev/null 2>&1; then
  systemctl --user enable pipewire.service pipewire-pulse.service wireplumber.service || true
else
  warn "User systemd is not up in this shell. Pipewire will start with the graphical session."
fi
sudo systemctl enable power-profiles-daemon.service || true
if compgen -G '/sys/class/bluetooth/*' >/dev/null; then
  sudo systemctl enable bluetooth.service || true
fi

command -v xdg-user-dirs-update >/dev/null && xdg-user-dirs-update || true

cat <<EOF

Installed deomarchy $VERSION.

  Login:    tuigreet on tty1 after reboot (greetd). It is not started yet,
            so this shell stays up.
  Lock:     Super+Ctrl+L  (hyprlock, drawn like the greeter)
  Apps:     Super+Space   (Walker)
  Menu:     Super+Alt+Space
  Browser:  $BROWSER_SUMMARY
  Web apps: only what you picked ($WEBAPPS). Menu → Web app → Choose from list
  Fetch:    $FETCH_SUMMARY
  Theme:    catppuccin-mocha (Super+Shift+Ctrl+Space to switch)

Reboot before judging the session. The hardware report is in
~/deomarchy-hardware.txt

This did not raise sudo retries, did not loosen faillock, did not add you to
the docker group, and did not install the Omarchy package.
EOF
