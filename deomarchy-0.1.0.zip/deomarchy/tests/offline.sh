#!/usr/bin/env bash
# Syntax and unit checks that do not need Arch, pacman, or a GPU.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

# Avoid process substitution; some environments have no /dev/fd.
find "$ROOT" -type f \( -name '*.sh' -o -path '*/bin/*' \) -print0 |
  while IFS= read -r -d '' f; do
    bash -n "$f"
  done

tmp="$(mktemp -d)"
export HOME="$tmp/home"
mkdir -p "$HOME"
export PATH="$ROOT/bin:$PATH"
export DEO_SHARE="$ROOT/share"
unset WAYLAND_DISPLAY
deo-theme-set catppuccin-mocha >/dev/null
test -f "$HOME/.config/deomarchy/current/hyprlock.conf"
test -f "$HOME/.config/deomarchy/current/waybar.css"
test -f "$HOME/.config/deomarchy/current/background.png"
test -f "$HOME/.config/deomarchy/current/alacritty.toml"
grep -q 'password' "$HOME/.config/deomarchy/current/hyprlock.conf"
grep -q 'JetBrainsMono' "$HOME/.config/deomarchy/current/hyprlock.conf"
grep -q 'catppuccin-mocha' "$HOME/.config/deomarchy/current/name"
grep -q 'cba6f7' "$HOME/.config/deomarchy/current/hyprland.conf"
grep -q '181825' "$HOME/.config/deomarchy/current/waybar.css"
grep -q 'dim_foreground' "$HOME/.config/deomarchy/current/alacritty.toml"
grep -q '89b4fa' "$DEO_SHARE/walker/themes/deomarchy/style.css"
link="$(readlink "$HOME/.config/deomarchy/current/background")"
[[ $link == *catppuccin-mocha/backgrounds/* ]]
grep -q 'color_theme = "catppuccin-mocha"' "$HOME/.config/btop/btop.conf"

mkdir -p "$tmp/bin"
printf '#!/bin/sh\nexit 1\n' >"$tmp/bin/curl"
chmod +x "$tmp/bin/curl"
export PATH="$tmp/bin:$ROOT/bin:${PATH:-}"

set +e
deo-webapp-install 'bad/name' 'https://example.com' >/tmp/deo-test.out 2>&1
code=$?
set -e
test "$code" -ne 0
grep -q 'invalid app name' /tmp/deo-test.out

set +e
deo-webapp-install 'Ok App' 'javascript:alert(1)' >/tmp/deo-test.out 2>&1
code=$?
set -e
test "$code" -ne 0
grep -q 'why:' /tmp/deo-test.out
grep -q 'javascript' /tmp/deo-test.out
grep -q 'Ok App' /tmp/deo-test.out
test ! -e "$HOME/.local/share/applications/Ok App.desktop"

set +e
deo-webapp-install 'Ok App' '' >/tmp/deo-test.out 2>&1
code=$?
set -e
test "$code" -ne 0
grep -q 'empty' /tmp/deo-test.out

deo-webapp-install-defaults --none >/tmp/deo-test.out
grep -q 'nothing installed' /tmp/deo-test.out
test ! -e "$HOME/.local/share/applications/HEY.desktop"

deo-webapp-install-defaults HEY >/tmp/deo-test.out
grep -q 'url: https://app.hey.com' /tmp/deo-test.out
grep -q 'installed: HEY' /tmp/deo-test.out
grep -q 'deo-webapp-handler-hey' "$HOME/.local/share/applications/HEY.desktop"

set +e
deo-webapp-install-defaults 'Not An App' >/tmp/deo-test.out 2>&1
code=$?
set -e
test "$code" -ne 0
grep -q 'not in the catalog' /tmp/deo-test.out
grep -q 'HEY' /tmp/deo-test.out

bash "$ROOT/install.sh" --help >/tmp/deo-test.out
grep -q -- '--fetch' /tmp/deo-test.out
grep -q -- '--webapps' /tmp/deo-test.out
grep -q -- '--skip-update' /tmp/deo-test.out
grep -q -- '--browser' /tmp/deo-test.out
grep -q 'catppuccin-mocha' /tmp/deo-test.out
grep -q '0.1.0' /tmp/deo-test.out
grep -q 'ungoogled, drm, or chromium' /tmp/deo-test.out

set +e
bash "$ROOT/install.sh" --fetch wat >/tmp/deo-test.out 2>&1
code=$?
set -e
test "$code" -ne 0
grep -q 'Unknown --fetch' /tmp/deo-test.out

set +e
bash "$ROOT/install.sh" --browser nope >/tmp/deo-test.out 2>&1
code=$?
set -e
test "$code" -ne 0
grep -q 'ungoogled, drm, or chromium' /tmp/deo-test.out
grep -q 'widevine) BROWSER=drm' "$ROOT/install.sh"

fake="$(mktemp -d)"
cat >"$fake/pacman" <<'EOF'
#!/bin/bash
# -Qq with no target lists real package names. A provide is not a package.
if [[ $# -eq 1 && $1 == -Qq ]]; then
  printf '%s\n' ungoogled-chromium-widevine-bin
  exit 0
fi
exit 1
EOF
chmod +x "$fake/pacman"
(
  export PATH="$fake:$PATH"
  # shellcheck source=lib/packages.sh
  source "$ROOT/lib/packages.sh"
  pkg_installed ungoogled-chromium-widevine-bin
  if pkg_installed chromium; then
    echo "chromium was treated as installed" >&2
    exit 1
  fi
)

rm -rf "$tmp" "$fake"
echo "offline checks ok"
