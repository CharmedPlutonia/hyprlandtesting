# deomarchy

A Hyprland shell for **plain Arch**. It takes the pre-Quickshell Omarchy desktop
(tag `v3.8.4`: Waybar, Walker, Elephant, Mako, SwayOSD, the Hyprland binds) and
leaves the Omarchy distribution behind.

Omarchy 4 replaced that shell with Quickshell. This tracks the last release that
still is Waybar + Walker.

## What you get

- Hyprland config split the same way Omarchy 3.8 split it: shared defaults, and
  a small `~/.config/hypr` you are meant to edit (monitors, input, app binds).
- Waybar, Walker, Mako, SwayOSD, hypridle, and the same keybinds (Super+Space
  launcher, Super+Alt+Space menu, web-app letters, screenshots, volume keys).
- Web apps: install, remove, frameless `--app` windows, Walker entries, the
  Omarchy 3.8 default set (HEY, Basecamp, WhatsApp, Google properties, ChatGPT,
  YouTube, GitHub, X, Figma, Discord, Zoom, Fizzy) plus Grok. Zoom links open
  the web client. Alt+Shift+L copies the URL inside those windows.
- **tuigreet** on greetd for login.
- **hyprlock** for the session lock, drawn like the greeter: monospace, clock,
  framed password, asterisks, solid color, no blurred wallpaper. tuigreet cannot
  lock a running Wayland session. hyprlock can, and this config is the match.
- **ungoogled-chromium-widevine-bin** from the AUR instead of Chromium/Chrome.
  Widevine is the DRM blob; the script makes `libwidevinecdm.so` executable,
  which that package has gotten wrong before.
- A hardware scan that installs microcode plus the AMD, Intel, or NVIDIA stack
  it actually sees, and QEMU/VirtualBox/VMware guests when you are in a VM.

## What it refuses to copy from Omarchy

These are the concrete problems, not a vibe:

| Left out | Why |
| --- | --- |
| `omarchy` package, menu installers, updater, custom kernel | This stays Arch. Updates are `yay -Syu`, which waits for you. |
| Raised sudo retries and loosened faillock | Those weaken the defaults Arch ships. |
| Passwordless sudo, docker group | Docker-group membership is root. It is not installed. |
| Bootloader, Limine, Plymouth, LUKS changes | archinstall already owns the disk. Touching the bootloader from a desktop script is how VMs get stranded. |
| Random Broadcom/Realtek DKMS | If Wi-Fi does not appear, the report prints the PCI id. It does not guess a DKMS module. |
| Voxtype, screensaver, Windows VM, forced HEY mailto | HEY is installed as a web app. It does not become your mailto handler unless you pass `--hey-mailto`. |
| Google account OAuth baked into Chromium | The browser is ungoogled. Icons come from DuckDuckGo or the site's own favicon, not Google's favicon service. |
| Web app names passed through a shell | Names and URLs are checked. A name cannot contain a slash. A custom handler has to be one of the `deo-webapp-handler-*` scripts. |

## Install

archinstall → profile **minimal** (no desktop). Boot it, log in as your user, then:

```bash
git clone https://github.com/YOU/deomarchy.git
cd deomarchy
./install.sh --dry-run    # hardware report and package list, no changes
./install.sh
reboot
```

The script is idempotent. Run it again after you pull. Pass `--reconfigure` only
when you want the shipped `~/.config` files replaced (it keeps a `.bak` copy).

First boot after install is tuigreet on tty1. Your old SSH session is not killed
during the install; greetd is enabled, not started.

### Useful flags

```bash
./install.sh --dry-run
./install.sh --hey-mailto     # also claim mailto: for HEY
./install.sh --skip-aur       # no browser, no Walker; not useful on a real machine
./install.sh --reconfigure
```

## Keys

| Keys | Action |
| --- | --- |
| Super + Space | Walker |
| Super + Alt + Space | Menu (system, theme, background, capture, web app, power) |
| Super + K | Searchable keybindings |
| Super + Return | Terminal in the focused terminal's directory |
| Super + Shift + Return | Browser |
| Super + Shift + B | Browser, again (same bind Omarchy used) |
| Super + Shift + Alt + B | Private window |
| Super + Shift + F | Files |
| Super + Q is not close | Close is Super + W, same as Omarchy 3.8 |
| Super + Ctrl + L | Lock |
| Print | Screenshot |
| Super + Shift + A / E / Y / X | ChatGPT, HEY, YouTube, X |
| Alt + Shift + L | Copy URL inside a web app |

Monitors default to **1x** so a VM is not a tiny 2x retina desktop. Retina
settings are commented in `~/.config/hypr/monitors.conf`.

Themes included as colors only (no wallpaper pack): tokyo-night (default),
catppuccin, catppuccin-latte, gruvbox, nord, everforest, kanagawa, rose-pine,
matte-black, osaka-jade. `deo-theme-set nord` switches them.

## Layout

```text
install.sh          entry point
lib/hardware.sh     PCI / CPU / VM scan and driver install
bin/deo-*           the shell commands (installed to ~/.local/bin)
config/             files copied to ~/.config on first run
share/              defaults, themes, Copy-URL extension
```

Hyprland reads `~/.config/hypr/hyprland.conf`, which sources the shared defaults
and then your files. Edit `bindings.conf`, `input.conf`, and `monitors.conf`.
Re-running the installer does not overwrite those unless you ask.

## VM notes

- Virtio/QXL gets `mesa` plus `qemu-guest-agent` and `spice-vdagent` under KVM.
- 3D acceleration in the VM makes Wayland happier. Without it, Hyprland can
  still start on llvmpipe; it will just be slow.
- greetd takes tty1 after reboot. Keep a second tty or an SSH session the first
  time, in case the session command needs `~/.config/hypr/monitors.conf` tweaked.

## Upstream

Configs and the screenshot/recording scripts are adapted from
[omacom/omarchy v3.8.4](https://github.com/omacom/omarchy/tree/v3.8.4) (MIT).
This tree is not affiliated with Omarchy or 37signals.
