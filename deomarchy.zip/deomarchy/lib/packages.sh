#!/usr/bin/env bash
# Official package list for the shell. Missing names are skipped and reported.
set -euo pipefail

official_packages() {
  cat <<'EOF'
base-devel
git
curl
ca-certificates
pciutils
usbutils
jq
gum
python
imagemagick
file
pacman-contrib
xdg-utils
xdg-user-dirs
xdg-desktop-portal
xdg-desktop-portal-hyprland
xdg-desktop-portal-gtk
hyprland
uwsm
hyprlock
hypridle
hyprpicker
hyprsunset
waybar
mako
swaybg
swayosd
polkit
polkit-gnome
qt5-wayland
qt6-wayland
qt6ct
kvantum
alacritty
xdg-terminal-exec
nautilus
gnome-calculator
grim
slurp
satty
wl-clipboard
cliphist
brightnessctl
pamixer
playerctl
power-profiles-daemon
upower
ttf-jetbrains-mono-nerd
noto-fonts
noto-fonts-cjk
noto-fonts-emoji
greetd
greetd-tuigreet
pipewire
pipewire-pulse
pipewire-alsa
wireplumber
networkmanager
bluez
bluez-utils
fastfetch
btop
tmux
neovim
imv
mpv
ffmpeg
pavucontrol
libnotify
gpu-screen-recorder
v4l-utils
mesa
linux-firmware
EOF
}

# Tried from the AUR only when pacman does not already ship them.
aur_candidates() {
  cat <<'EOF'
ungoogled-chromium-widevine-bin
walker
elephant
wiremix
impala
bluetui
EOF
}
