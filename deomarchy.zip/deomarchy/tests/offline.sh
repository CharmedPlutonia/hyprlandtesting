#!/usr/bin/env bash
# Syntax and unit checks that do not need Arch, pacman, or a GPU.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

# Avoid process substitution; some environments have no /dev/fd.
find "$ROOT" -type f \( -name '*.sh' -o -path '*/bin/*' \) -print0 |
  while IFS= read -r -d '' f; do
    bash -n "$f"
  done

tmp="$(mktemp -d)"
export HOME="$tmp/home"
mkdir -p "$HOME"
export PATH="$ROOT/bin:$PATH"
export DEO_SHARE="$ROOT/share"
unset WAYLAND_DISPLAY
deo-theme-set tokyo-night >/dev/null
test -f "$HOME/.config/deomarchy/current/hyprlock.conf"
test -f "$HOME/.config/deomarchy/current/waybar.css"
test -f "$HOME/.config/deomarchy/current/background.png"
grep -q 'password' "$HOME/.config/deomarchy/current/hyprlock.conf"
grep -q 'JetBrainsMono' "$HOME/.config/deomarchy/current/hyprlock.conf"
grep -q 'tokyo-night' "$HOME/.config/deomarchy/current/name"

set +e
deo-webapp-install 'bad/name' 'https://example.com' >/tmp/deo-test.out 2>&1
code=$?
set -e
test "$code" -ne 0

set +e
deo-webapp-install 'Ok App' 'javascript:alert(1)' >/tmp/deo-test.out 2>&1
code=$?
set -e
test "$code" -ne 0
test ! -e "$HOME/.local/share/applications/Ok App.desktop"

rm -rf "$tmp"
echo "offline checks ok"
