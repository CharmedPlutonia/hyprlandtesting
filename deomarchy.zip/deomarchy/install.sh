#!/usr/bin/env bash
# deomarchy — Hyprland shell from Omarchy 3.8.4, installed onto plain Arch.
# Does not install Omarchy, its repo, its kernel, or its loosened sudo/PAM.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib/common.sh
source "$ROOT/lib/common.sh"
# shellcheck source=lib/packages.sh
source "$ROOT/lib/packages.sh"

DRY=0
RECONFIGURE=0
SKIP_AUR=0
HEY_MAILTO=0

usage() {
  cat <<EOF
Usage: ./install.sh [options]

  --dry-run        Print the hardware report and package list. Change nothing.
  --reconfigure    Overwrite ~/.config files shipped by this repo (backs them up).
  --skip-aur       Skip yay and every AUR package, including the browser.
  --hey-mailto     Make the HEY web app the default mailto: handler.
  -h, --help       Show this help.

Run it from a normal user on a base Arch install (archinstall's minimal
profile is the intended starting point). Reboot when it finishes.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --dry-run) DRY=1 ;;
    --reconfigure) RECONFIGURE=1 ;;
    --skip-aur) SKIP_AUR=1 ;;
    --hey-mailto) HEY_MAILTO=1 ;;
    -h | --help) usage; exit 0 ;;
    *) die "Unknown option: $1" ;;
  esac
  shift
done

require_arch
require_user

log "Hardware"
bash "$ROOT/lib/hardware.sh" --report | tee "$HOME/deomarchy-hardware.txt"

if [[ $DRY -eq 1 ]]; then
  log "Official packages"
  official_packages
  log "AUR candidates (installed only when pacman does not have them)"
  aur_candidates
  log "Dry run only. Nothing was installed."
  exit 0
fi

log "Refreshing package databases and installing the shell"
sudo pacman -Syu --noconfirm
mapfile -t wanted < <(official_packages)
have=()
missing=()
for pkg in "${wanted[@]}"; do
  if pacman -Si "$pkg" >/dev/null 2>&1; then
    have+=("$pkg")
  else
    missing+=("$pkg")
  fi
done
if [[ ${#have[@]} -gt 0 ]]; then
  sudo pacman -S --needed --noconfirm "${have[@]}"
fi
if [[ ${#missing[@]} -gt 0 ]]; then
  warn "Not in the official repos (skipped): ${missing[*]}"
fi

log "Drivers for this machine"
bash "$ROOT/lib/hardware.sh" --install

install_yay() {
  if command -v yay >/dev/null 2>&1; then
    return
  fi
  log "Installing yay-bin"
  local tmp
  tmp="$(mktemp -d)"
  git clone --depth 1 https://aur.archlinux.org/yay-bin.git "$tmp/yay-bin"
  (cd "$tmp/yay-bin" && makepkg -si --noconfirm)
  rm -rf "$tmp"
}

install_aur() {
  local pkg
  install_yay
  # The widevine package conflicts with the distro chromium package.
  if pacman -Q chromium >/dev/null 2>&1; then
    warn "Removing distro chromium so ungoogled-chromium-widevine-bin can replace it"
    sudo pacman -Rns --noconfirm chromium
  fi
  for pkg in $(aur_candidates); do
    if pacman -Si "$pkg" >/dev/null 2>&1; then
      sudo pacman -S --needed --noconfirm "$pkg" && continue
    fi
    if [[ $pkg == ungoogled-chromium-widevine-bin ]]; then
      yay -S --needed --noconfirm --answerdiff None --answerclean All --removemake "$pkg" \
        || die "Could not install ungoogled-chromium with Widevine."
    else
      yay -S --needed --noconfirm --answerdiff None --answerclean All --removemake "$pkg" \
        || warn "AUR package failed: $pkg (the shell still runs without it)"
    fi
  done
}

if [[ $SKIP_AUR -eq 0 ]]; then
  log "AUR packages (browser, walker, TUIs)"
  install_aur
else
  warn "Skipping AUR. You will not get ungoogled-chromium or Walker."
fi

log "Installing shell files"
mkdir -p "$HOME/.local/bin" "$HOME/.local/share" "$HOME/.config/hypr/toggles" "$HOME/.config/deomarchy"
rm -rf "$HOME/.local/share/deomarchy"
cp -a "$ROOT/share" "$HOME/.local/share/deomarchy"
find "$HOME/.local/share/deomarchy" -type f -name '*.sh' -exec chmod 755 {} +
while IFS= read -r -d '' src; do
  install -m 755 "$src" "$HOME/.local/bin/$(basename "$src")"
done < <(find "$ROOT/bin" -maxdepth 1 -type f -print0)

# User configs are copied once. --reconfigure replaces them after a backup.
while IFS= read -r -d '' src; do
  rel="${src#"$ROOT/config/"}"
  dest="$HOME/.config/$rel"
  if [[ -e $dest && $RECONFIGURE -eq 0 ]]; then
    continue
  fi
  mkdir -p "$(dirname "$dest")"
  if [[ -e $dest ]]; then
    cp -a "$dest" "$dest.bak.$(date +%Y%m%d%H%M%S)"
  fi
  cp -a "$src" "$dest"
done < <(find "$ROOT/config" -type f -print0)

if [[ ! -f $HOME/.config/hypr/toggles/keep.conf ]]; then
  printf '%s\n' "# placeholder so Hyprland's toggle glob always matches" \
    >"$HOME/.config/hypr/toggles/keep.conf"
fi

# NVIDIA hardware.sh may have written hardware.conf before the template copy.
# Re-run driver env generation if the card is present and the file is still a stub.
if lspci -nn 2>/dev/null | grep -Eiq 'nvidia' && ! grep -q nvidia "$HOME/.config/hypr/hardware.conf"; then
  bash "$ROOT/lib/hardware.sh" --install
fi

mkdir -p "$HOME/.local/share/deomarchy"
cp -f "$HOME/deomarchy-hardware.txt" "$HOME/.local/share/deomarchy/hardware-report.txt" || true

path_line='export PATH="$HOME/.local/bin:$PATH"  # deomarchy'
for rc in "$HOME/.bashrc" "$HOME/.zshrc"; do
  [[ -f $rc ]] || continue
  grep -q 'deomarchy' "$rc" || printf '\n%s\n' "$path_line" >>"$rc"
done
if [[ ! -f $HOME/.bashrc ]]; then
  printf '%s\n' "$path_line" >"$HOME/.bashrc"
fi

mkdir -p "$HOME/.config/uwsm"
if [[ ! -f $HOME/.config/uwsm/env ]] || ! grep -q '/.local/bin' "$HOME/.config/uwsm/env"; then
  printf '%s\n' 'export PATH="$HOME/.local/bin:$PATH"' >>"$HOME/.config/uwsm/env"
fi

export PATH="$HOME/.local/bin:$PATH"
export DEO_SHARE="$HOME/.local/share/deomarchy"

log "Theme (tokyo-night)"
deo-theme-set tokyo-night

if [[ $SKIP_AUR -eq 0 ]]; then
  log "Browser flags, Widevine, default web apps"
  ext="$HOME/.local/share/deomarchy/chromium/extensions/copy-url"
  cat >"$HOME/.config/chromium-flags.conf" <<EOF
--ozone-platform=wayland
--ozone-platform-hint=auto
--enable-features=TouchpadOverscrollHistoryNavigation,VaapiVideoDecodeLinuxGL
--disable-features=DisableLoadExtensionCommandLineSwitch
--load-extension=${ext}
EOF
  cp -f "$HOME/.config/chromium-flags.conf" "$HOME/.config/ungoogled-chromium-flags.conf"

  while IFS= read -r so; do
    [[ -n $so ]] || continue
    sudo chmod 755 "$so" || true
    log "Widevine module: $so"
  done < <(find /usr/lib /opt -name 'libwidevinecdm.so' 2>/dev/null || true)

  desktop=""
  for candidate in ungoogled-chromium.desktop chromium.desktop; do
    if [[ -f /usr/share/applications/$candidate ]]; then
      desktop="$candidate"
      break
    fi
  done
  if [[ -n $desktop ]]; then
    mkdir -p "$HOME/.config"
    mime="$HOME/.config/mimeapps.list"
    touch "$mime"
    for handler in text/html x-scheme-handler/http x-scheme-handler/https; do
      if grep -q "^${handler}=" "$mime"; then
        sed -i "s|^${handler}=.*|${handler}=${desktop}|" "$mime"
      else
        if grep -q '^\[Default Applications\]' "$mime"; then
          sed -i "/^\[Default Applications\]/a ${handler}=${desktop}" "$mime"
        else
          printf '\n[Default Applications]\n%s=%s\n' "$handler" "$desktop" >>"$mime"
        fi
      fi
    done
    xdg-settings set default-web-browser "$desktop" || true
    xdg-mime default "$desktop" text/html || true
    xdg-mime default "$desktop" x-scheme-handler/http || true
    xdg-mime default "$desktop" x-scheme-handler/https || true
  else
    warn "Browser desktop file not found. Web apps will not launch until it is installed."
  fi

  if [[ $HEY_MAILTO -eq 1 ]]; then
    DEO_HEY_MAILTO=1 deo-webapp-install-defaults
  else
    deo-webapp-install-defaults
  fi
fi

log "Groups (not docker, not a passwordless sudo rule)"
for group in video input audio storage render; do
  if getent group "$group" >/dev/null; then
    sudo usermod -aG "$group" "$USER"
  fi
done

log "greetd + tuigreet"
session=""
if [[ -f /usr/share/wayland-sessions/hyprland-uwsm.desktop ]]; then
  session="uwsm start hyprland-uwsm.desktop"
elif [[ -f /usr/share/wayland-sessions/hyprland.desktop ]]; then
  session="uwsm start -- hyprland.desktop"
else
  session="Hyprland"
fi

sudo mkdir -p /etc/greetd
sudo tee /etc/greetd/config.toml >/dev/null <<EOF
[terminal]
vt = 1

[default_session]
command = "/usr/bin/tuigreet --time --time-format '%A  %H:%M' --remember --remember-user-session --asterisks --window-padding 2 --container-padding 1 --greeting 'login' --theme 'border=cyan;text=white;prompt=cyan;time=blue;action=green;button=magenta;container=black;input=red' --cmd '${session}'"
user = "greeter"
EOF
sudo chmod 644 /etc/greetd/config.toml

for dm in gdm sddm lightdm lxdm; do
  if systemctl is-enabled "$dm.service" >/dev/null 2>&1; then
    warn "Disabling $dm so greetd can own the login screen"
    sudo systemctl disable "$dm.service" || true
  fi
done
sudo systemctl enable greetd.service

log "Services"
# Do not steal the network stack if archinstall already brought one up.
if systemctl is-active --quiet NetworkManager; then
  sudo systemctl enable NetworkManager.service
elif systemctl is-active --quiet systemd-networkd || systemctl is-active --quiet iwd; then
  warn "Leaving the current network manager alone."
else
  sudo systemctl enable --now NetworkManager.service || true
fi

if systemctl --user status >/dev/null 2>&1; then
  systemctl --user enable pipewire.service pipewire-pulse.service wireplumber.service || true
else
  warn "User systemd is not up in this shell. Pipewire will start with the graphical session."
fi
sudo systemctl enable power-profiles-daemon.service || true
if compgen -G '/sys/class/bluetooth/*' >/dev/null; then
  sudo systemctl enable bluetooth.service || true
fi

command -v xdg-user-dirs-update >/dev/null && xdg-user-dirs-update || true

cat <<EOF

Installed.

  Login:    tuigreet on tty1 after reboot (greetd). It is not started yet,
            so this shell stays up.
  Lock:     Super+Ctrl+L  (hyprlock, drawn like the greeter)
  Apps:     Super+Space   (Walker)
  Menu:     Super+Alt+Space
  Browser:  Super+Shift+Return  (ungoogled-chromium, if the AUR build succeeded)
  Web app:  menu → Web app, or the Super+Shift letter binds
  Theme:    Super+Shift+Ctrl+Space

Reboot before judging the session. The hardware report is in
~/deomarchy-hardware.txt

This did not raise sudo retries, did not loosen faillock, did not add you to
the docker group, and did not install the Omarchy package.
EOF
